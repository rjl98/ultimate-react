{
    /* <div className="mb-3">
                    <label htmlFor="type" className="form-label">
                        Tipo
                    </label>
                    <select className="form-select" name="type" id="type">
                        <option defaultValue="">-- Selecciona tipo --</option>
                        <option value="Familiar">Familiar</option>
                        <option value="Trabajo">Trabajo</option>
                        <option value="Amigo">Amigo</option>
                        <option value="Otros">Otros</option>
                    </select>
                </div> */
}
