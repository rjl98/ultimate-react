import MealFinder from "./mealFinder/mealFinder";

const App = () => {
    return <MealFinder />;
};

export default App;
